# Static Provisioning

- PVC, PV를 사용해 1개 이상의 Pod에서 EFS 사용 가능

[Exxample on Github](https://github.com/kubernetes-sigs/aws-efs-csi-driver/tree/master/examples/kubernetes/multiple_pods)