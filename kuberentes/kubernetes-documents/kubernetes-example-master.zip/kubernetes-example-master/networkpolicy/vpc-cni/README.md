
Please refer to official document

- https://docs.aws.amazon.com/ko_kr/eks/latest/userguide/security-groups-for-pods.html